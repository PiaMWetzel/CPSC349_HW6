class ChatApp {
    constructor() {
        console.log('Hello ES6!');
        }
}
export default ChatApp;
